package vn.danchoismp.anticheat;

import com.github.retrooper.packetevents.PacketEvents;
import java.util.Map;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DanChoiSmpAnticheat extends JavaPlugin implements CommandExecutor {

    private ViolationManager violations;
    private PacketCheck packetCheck;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        violations = new ViolationManager(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(violations, this);
        pm.registerEvents(new CombatCheck(this, violations), this);
        pm.registerEvents(new VelocityCheck(this, violations), this);
        pm.registerEvents(new CartCheck(this, violations), this);
        pm.registerEvents(new CrystalCheck(this, violations), this);
        pm.registerEvents(new ChatCheck(this, violations), this);

        // Check dựa trên packet (PacketEvents được cài như plugin riêng, đã tự khởi tạo API)
        packetCheck = new PacketCheck(this, violations);
        PacketEvents.getAPI().getEventManager().registerListener(packetCheck);
        pm.registerEvents(packetCheck, this);

        getCommand("ac").setExecutor(this);
        getLogger().info("DanChoiSmpAnticheat đã bật."
                + (yieldToGrim() ? " Phát hiện GrimAC: tự nhường các check trùng." : ""));
    }

    @Override
    public void onDisable() {
        if (packetCheck != null) {
            PacketEvents.getAPI().getEventManager().unregisterListener(packetCheck);
        }
    }

    /** True nếu GrimAC đang chạy và config cho phép nhường các check trùng lặp. */
    public boolean yieldToGrim() {
        return getConfig().getBoolean("grim-compat.yield-overlapping-checks", true)
                && getServer().getPluginManager().isPluginEnabled("GrimAC");
    }

    @Override
    public boolean onCommand(CommandSender s, Command cmd, String label, String[] a) {
        if (a.length == 0) {
            s.sendMessage("§e/ac reload §7| §e/ac alerts §7| §e/ac vl <người chơi>");
            return true;
        }
        switch (a[0].toLowerCase()) {
            case "reload":
                reloadConfig();
                s.sendMessage("§aĐã tải lại config.");
                break;
            case "alerts":
                if (!(s instanceof Player)) {
                    s.sendMessage("Chỉ dùng trong game.");
                    break;
                }
                boolean on = violations.toggleAlerts(((Player) s).getUniqueId());
                s.sendMessage(on ? "§aĐã bật cảnh báo." : "§cĐã tắt cảnh báo.");
                break;
            case "vl":
                if (a.length < 2) {
                    s.sendMessage("§cDùng: /ac vl <người chơi>");
                    break;
                }
                Player t = getServer().getPlayerExact(a[1]);
                if (t == null) {
                    s.sendMessage("§cKhông tìm thấy người chơi.");
                    break;
                }
                Map<String, Double> m = violations.getVl(t.getUniqueId());
                if (m.isEmpty()) s.sendMessage("§7" + t.getName() + " chưa có vi phạm.");
                else m.forEach((k, v) -> s.sendMessage("§7" + k + ": §e" + String.format("%.1f", v)));
                break;
            default:
                s.sendMessage("§cLệnh không hợp lệ.");
        }
        return true;
    }
}
