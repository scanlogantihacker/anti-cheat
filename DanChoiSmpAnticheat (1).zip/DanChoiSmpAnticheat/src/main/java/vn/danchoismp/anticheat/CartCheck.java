package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Auto TNT Minecart: đặt ray -> đặt cart quá nhanh, đổi slot rồi đặt ngay, spam cart. */
public class CartCheck implements Listener {

    private static class State {
        long lastRail, lastSwitch;
        final Deque<Long> carts = new ArrayDeque<>();
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public CartCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    private State state(Player p) {
        return states.computeIfAbsent(p.getUniqueId(), k -> new State());
    }

    @EventHandler(ignoreCancelled = true)
    public void onSwitch(PlayerItemHeldEvent e) {
        state(e.getPlayer()).lastSwitch = System.currentTimeMillis();
    }

    @EventHandler(ignoreCancelled = true)
    public void onRail(BlockPlaceEvent e) {
        if (Util.isRail(e.getBlockPlaced().getType())) {
            state(e.getPlayer()).lastRail = System.currentTimeMillis();
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCart(PlayerInteractEvent e) {
        if (e.getAction() != Action.RIGHT_CLICK_BLOCK || e.getItem() == null) return;
        if (e.getItem().getType() != Material.TNT_MINECART) return;
        if (e.getClickedBlock() == null || !Util.isRail(e.getClickedBlock().getType())) return;

        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("cart.enabled", true)) return;
        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;

        State s = state(p);
        long now = System.currentTimeMillis();
        s.carts.addLast(now);
        while (!s.carts.isEmpty() && now - s.carts.peekFirst() > 2000) s.carts.pollFirst();

        long railDelta = now - s.lastRail;
        long switchDelta = now - s.lastSwitch;
        String info = null;

        if (railDelta < c.getLong("cart.min-rail-to-cart-ms", 100)) {
            info = "đặt ray → cart sau " + railDelta + "ms";
        } else if (switchDelta < c.getLong("cart.min-switch-to-use-ms", 60)) {
            info = "đổi slot → đặt cart sau " + switchDelta + "ms";
        } else if (s.carts.size() > c.getInt("cart.max-carts-per-2s", 4)) {
            info = s.carts.size() + " cart/2s";
        }

        if (info != null) {
            vm.flag(p, "AutoCart", info, 1.5);
            e.setCancelled(true);
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
