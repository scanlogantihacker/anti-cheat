package vn.danchoismp.anticheat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerVelocityEvent;
import org.bukkit.util.Vector;

/** Anti-KB: sau khi bị đẩy, đo quãng đường thực tế so với dự kiến. */
public class VelocityCheck implements Listener {

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, Integer> tokens = new HashMap<>();

    public VelocityCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onVelocity(PlayerVelocityEvent e) {
        if (!plugin.getConfig().getBoolean("velocity.enabled", true) || plugin.yieldToGrim()) return;
        Player p = e.getPlayer();
        if (Util.skip(plugin, p)) return;

        Vector v = e.getVelocity();
        double horiz = Math.hypot(v.getX(), v.getZ());
        // luôn đổi token để vô hiệu các lần đo cũ (tránh đo chồng nhiều lần knockback)
        int token = tokens.merge(p.getUniqueId(), 1, Integer::sum);

        if (horiz < plugin.getConfig().getDouble("velocity.min-horizontal", 0.25)) return;
        if (p.isFlying() || p.getAllowFlight() || p.isGliding() || p.isInsideVehicle()
                || p.isDead() || p.getGameMode() == GameMode.CREATIVE) return;
        if (Util.specialEnvironment(p)) return;

        Location start = p.getLocation();
        Vector dir = new Vector(v.getX(), 0, v.getZ()).normalize();
        if (Util.pathBlocked(start, dir)) return;

        long delay = 6 + Math.min(Math.max(p.getPing(), 0), 250) / 50;
        Bukkit.getScheduler().runTaskLater(plugin, () -> verify(p, token, start, dir, horiz), delay);
    }

    private void verify(Player p, int token, Location start, Vector dir, double horiz) {
        if (!p.isOnline() || p.isDead()) return;
        if (tokens.getOrDefault(p.getUniqueId(), 0) != token) return;
        if (!p.getWorld().equals(start.getWorld())) return;
        if (p.isFlying() || p.isGliding() || p.isInsideVehicle()) return;
        if (Util.specialEnvironment(p)) return;

        Location now = p.getLocation();
        Vector moved = new Vector(now.getX() - start.getX(), 0, now.getZ() - start.getZ());
        double projected = moved.dot(dir); // quãng đường theo hướng knockback
        double expected = horiz * plugin.getConfig().getDouble("velocity.expected-multiplier", 4.0);
        double ratio = plugin.getConfig().getDouble("velocity.min-ratio", 0.3);

        if (projected < expected * ratio) {
            vm.flag(p, "Velocity",
                    String.format("di chuyển %.2f / dự kiến %.2f", projected, expected), 1.0);
        }
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent e) {
        tokens.merge(e.getPlayer().getUniqueId(), 1, Integer::sum);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        tokens.remove(e.getPlayer().getUniqueId());
    }
}
