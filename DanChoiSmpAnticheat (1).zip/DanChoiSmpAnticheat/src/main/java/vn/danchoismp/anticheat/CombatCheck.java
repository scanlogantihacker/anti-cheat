package vn.danchoismp.anticheat;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Vector;

/**
 * Reach + Hitbox + KillAura (góc, xuyên tường).
 * Multi-target và tốc độ đánh đã chuyển sang PacketCheck.
 * Khi có GrimAC, Reach/Hitbox/góc nhìn được nhường cho Grim (xem grim-compat trong config).
 */
public class CombatCheck implements Listener {

    private static class State {
        double reachBuf, hitboxBuf;
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final Map<UUID, State> states = new HashMap<>();

    public CombatCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onHit(EntityDamageByEntityEvent e) {
        if (!(e.getDamager() instanceof Player)) return;
        if (e.getCause() != DamageCause.ENTITY_ATTACK) return;
        if (!(e.getEntity() instanceof LivingEntity)) return;

        Player p = (Player) e.getDamager();
        LivingEntity target = (LivingEntity) e.getEntity();
        if (target.getUniqueId().equals(p.getUniqueId()) || Util.skip(plugin, p)) return;

        FileConfiguration c = plugin.getConfig();
        boolean grim = plugin.yieldToGrim();
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        Location eye = p.getEyeLocation();
        BoundingBox box = target.getBoundingBox();
        double lag = Util.lagTolerance(p);
        double tol = c.getDouble("combat.lag-base-tolerance", 0.25) + lag;
        boolean cancel = false;

        Vector toTarget = box.getCenter().subtract(eye.toVector());
        double distCenter = toTarget.length();
        Vector eyeDir = eye.getDirection();

        // ---- Reach ----
        if (!grim && c.getBoolean("combat.reach.enabled", true)) {
            double max = p.getGameMode() == GameMode.CREATIVE
                    ? c.getDouble("combat.reach.max-creative", 6.0)
                    : c.getDouble("combat.reach.max", 3.0);
            double dist = Util.distanceToBox(eye, box);
            if (dist > max + tol) {
                s.reachBuf++;
                if (s.reachBuf >= c.getDouble("combat.reach.buffer", 2)) {
                    vm.flag(p, "Reach", String.format("%.2f block", dist), 1.0);
                    cancel = true;
                }
            } else {
                s.reachBuf = Math.max(0, s.reachBuf - 0.25);
            }
        }

        // ---- Hitbox ----
        if (!grim && c.getBoolean("combat.hitbox.enabled", true) && !box.contains(eye.toVector())) {
            double expand = c.getDouble("combat.hitbox.expand", 0.15) + lag * 0.5;
            if (box.clone().expand(expand).rayTrace(eye.toVector(), eyeDir, distCenter + 2) == null) {
                s.hitboxBuf++;
                if (s.hitboxBuf >= c.getDouble("combat.hitbox.buffer", 3)) {
                    vm.flag(p, "Hitbox", "không nhìn trúng mục tiêu", 1.0);
                    cancel = true;
                }
            } else {
                s.hitboxBuf = Math.max(0, s.hitboxBuf - 0.5);
            }
        }

        // ---- KillAura: góc nhìn ----
        if (!grim && c.getBoolean("combat.killaura.angle.enabled", true) && distCenter > 1.5) {
            double angle = Math.toDegrees(eyeDir.angle(toTarget));
            if (angle > c.getDouble("combat.killaura.angle.max-degrees", 80)) {
                vm.flag(p, "KillAura", "góc lệch " + (int) angle + "°", 1.5);
                cancel = true;
            }
        }

        // ---- KillAura: đánh xuyên tường ----
        if (c.getBoolean("combat.killaura.wall.enabled", true) && Util.wallBetween(eye, box)) {
            vm.flag(p, "KillAura", "đánh xuyên tường", 2.0);
            cancel = true;
        }

        if (cancel && c.getBoolean("combat.cancel-hits", true)) e.setCancelled(true);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
