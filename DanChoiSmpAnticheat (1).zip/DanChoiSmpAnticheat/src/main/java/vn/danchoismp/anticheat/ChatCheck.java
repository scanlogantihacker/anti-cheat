package vn.danchoismp.anticheat;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** Macro chat: gửi quá nhanh, lặp tin, spam, hoặc chu kỳ đều bất thường. */
public class ChatCheck implements Listener {

    private static class State {
        long last;
        String lastMsg = "";
        final Deque<Long> times = new ArrayDeque<>();
        final Deque<Long> intervals = new ArrayDeque<>();
    }

    private final DanChoiSmpAnticheat plugin;
    private final ViolationManager vm;
    private final ConcurrentHashMap<UUID, State> states = new ConcurrentHashMap<>();

    public ChatCheck(DanChoiSmpAnticheat plugin, ViolationManager vm) {
        this.plugin = plugin;
        this.vm = vm;
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncPlayerChatEvent e) {
        FileConfiguration c = plugin.getConfig();
        Player p = e.getPlayer();
        if (!c.getBoolean("chat.enabled", true) || p.hasPermission("anticheat.bypass")) return;

        long now = System.currentTimeMillis();
        String msg = e.getMessage().trim().toLowerCase();
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        String reason = null;

        synchronized (s) {
            long interval = s.last == 0 ? Long.MAX_VALUE : now - s.last;

            // 1) quá nhanh
            if (interval < c.getLong("chat.min-interval-ms", 600)) {
                reason = "gửi quá nhanh (" + interval + "ms)";
            }
            // 2) lặp tin
            if (reason == null && msg.equals(s.lastMsg)
                    && interval < c.getLong("chat.duplicate-window-ms", 5000)) {
                reason = "lặp lại tin nhắn";
            }
            // 3) quá nhiều tin trong khoảng thời gian
            s.times.addLast(now);
            long window = c.getLong("chat.window-seconds", 8) * 1000L;
            while (!s.times.isEmpty() && now - s.times.peekFirst() > window) s.times.pollFirst();
            if (reason == null && s.times.size() > c.getInt("chat.max-messages", 6)) {
                reason = s.times.size() + " tin / " + (window / 1000) + "s";
            }
            // 4) chu kỳ đều bất thường (macro)
            if (interval < 15_000) {
                s.intervals.addLast(interval);
                if (s.intervals.size() > 6) s.intervals.pollFirst();
            } else {
                s.intervals.clear();
            }
            if (reason == null && s.intervals.size() >= 6) {
                double mean = 0;
                for (long v : s.intervals) mean += v;
                mean /= s.intervals.size();
                double var = 0;
                for (long v : s.intervals) var += (v - mean) * (v - mean);
                double std = Math.sqrt(var / s.intervals.size());
                if (std < c.getDouble("chat.regular-std-ms", 35)) {
                    reason = String.format("chu kỳ đều ~%.0fms (macro)", mean);
                }
            }

            s.last = now;
            s.lastMsg = msg;
        }

        if (reason != null) {
            e.setCancelled(true);
            vm.flag(p, "ChatMacro", reason, 1.0);
            String warn = ChatColor.translateAlternateColorCodes('&',
                    c.getString("messages.chat-blocked", "&cBạn gửi tin nhắn quá nhanh."));
            Bukkit.getScheduler().runTask(plugin, () -> p.sendMessage(warn));
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent e) {
        states.remove(e.getPlayer().getUniqueId());
    }
}
