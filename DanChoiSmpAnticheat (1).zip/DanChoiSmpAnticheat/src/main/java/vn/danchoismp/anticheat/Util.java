package vn.danchoismp.anticheat;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public final class Util {

    private Util() {}

    /** Bỏ qua người có quyền bypass, spectator, hoặc khi server đang lag. */
    public static boolean skip(DanChoiSmpAnticheat plugin, Player p) {
        if (p.hasPermission("anticheat.bypass")) return true;
        if (p.getGameMode() == GameMode.SPECTATOR) return true;
        return Bukkit.getTPS()[0] < plugin.getConfig().getDouble("min-tps", 17.0);
    }

    /** Dung sai (block) tăng theo ping, tối đa tính tới 300ms. */
    public static double lagTolerance(Player p) {
        int ping = Math.max(0, Math.min(p.getPing(), 300));
        return ping / 1000.0 * 4.0;
    }

    /** Khoảng cách từ mắt tới điểm gần nhất của hitbox. */
    public static double distanceToBox(Location eye, BoundingBox b) {
        double dx = Math.max(Math.max(b.getMinX() - eye.getX(), 0), eye.getX() - b.getMaxX());
        double dy = Math.max(Math.max(b.getMinY() - eye.getY(), 0), eye.getY() - b.getMaxY());
        double dz = Math.max(Math.max(b.getMinZ() - eye.getZ(), 0), eye.getZ() - b.getMaxZ());
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static boolean blocked(Location eye, Vector point) {
        Vector dir = point.clone().subtract(eye.toVector());
        double len = dir.length();
        if (len < 0.5) return false;
        RayTraceResult r = eye.getWorld().rayTraceBlocks(eye, dir.normalize(), len,
                FluidCollisionMode.NEVER, true);
        return r != null && r.getHitBlock() != null && r.getHitBlock().getType().isOccluding();
    }

    /** True nếu cả 3 tia (giữa, đầu, chân) tới mục tiêu đều bị block chắn. */
    public static boolean wallBetween(Location eye, BoundingBox box) {
        double cx = box.getCenterX(), cz = box.getCenterZ();
        double[] ys = { box.getCenterY(), box.getMaxY() - 0.1, box.getMinY() + 0.1 };
        for (double y : ys) {
            if (!blocked(eye, new Vector(cx, y, cz))) return false;
        }
        return true;
    }

    /** Đang ở môi trường làm knockback bị sai lệch (nước, mạng nhện, thang...). */
    public static boolean specialEnvironment(Player p) {
        return special(p.getLocation().getBlock()) || special(p.getEyeLocation().getBlock());
    }

    private static boolean special(Block b) {
        if (b.isLiquid()) return true;
        String n = b.getType().name();
        return n.contains("WEB") || n.contains("LADDER") || n.contains("VINE")
                || n.contains("SCAFFOLDING") || n.contains("BERRY") || n.contains("POWDER_SNOW")
                || n.contains("HONEY") || n.contains("BUBBLE");
    }

    /** Có block đặc chắn trên đường knockback không. */
    public static boolean pathBlocked(Location start, Vector dir) {
        for (double d = 0.7; d <= 2.8; d += 0.7) {
            Location l = start.clone().add(dir.getX() * d, 0, dir.getZ() * d);
            if (l.getBlock().getType().isSolid()
                    || l.clone().add(0, 1, 0).getBlock().getType().isSolid()) return true;
        }
        return false;
    }

    public static boolean isRail(Material m) {
        return m == Material.RAIL || m == Material.POWERED_RAIL
                || m == Material.DETECTOR_RAIL || m == Material.ACTIVATOR_RAIL;
    }
}
